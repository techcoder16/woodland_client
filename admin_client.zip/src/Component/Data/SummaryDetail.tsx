import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState, AppDispatch } from '../../redux/store';
import { summaryData } from '../../redux/dataStore/dataSlice';
import { AiOutlineSearch } from 'react-icons/ai';
import { FaSort, FaSortUp, FaSortDown } from 'react-icons/fa';

const SummaryDetail = () => {
  const data: any = useSelector((state: RootState) => state.summary);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const dispatch = useDispatch<AppDispatch>();

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      dispatch(summaryData({ searchQuery, sortColumn, sortDirection }));
    }, 3000);

    return () => clearInterval(interval);
  }, [dispatch, searchQuery, sortColumn, sortDirection]);

  const getSortIcon = (column: string) => {
    if (sortColumn === column) {
      return sortDirection === 'asc' ? <FaSortUp className="ml-1" /> : <FaSortDown className="ml-1" />;
    } else {
      return <FaSort className="ml-1" />;
    }
  };

  return (
    <div>
      <div className="flex mt-20 items-end justify-end sm:justify-end p-10">
        <div className="absolute flex-shrink-0 items-center">
          <label htmlFor="simple-search" className="sr-only">
            Search
          </label>
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search Agent Name ..."
              className="bg-gray-50 border border-gray-600 mb-8 text-maincolor text-sm rounded-lg focus:ring-maincolor focus:border-maincolor block w-full pl-10 pr-10 p-2.5 focus:outline-none focus:ring-0"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
              <AiOutlineSearch className="w-5 h-5 text-maincolor dark:text-maincolor" />
            </div>
          </div>
        </div>
      </div>

      <div className="relative bg-white shadow-lg rounded-2xl border-1 border-gray-600 border-solid filter drop-shadow-2xl">
        <div className="p-8 md:p-14">
          <span className="mb-3 font-Overpass text-subheading-400 text-maincolor">Summary</span>
          <div className="overflow-auto scrollbar-thin scrollbar-thumb-maincolor">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-white decoration-gray-100">
                <tr>
                  {['userId', 'agentName', 'totalCalls', 'totalTalkTime', 'incomingTotal', 'incomingMissed', 'incomingAvgPerHour', 'incomingTalkTime', 'outgoingTotal', 'outgoingAvgPerHour'].map((col, index) => (
                    <th
                      key={index}
                      onClick={() => handleSort(col)}
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                    >
                      <div className="flex items-center">
                        {col}
                        {getSortIcon(col)}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {data && data.summary && data.summary.summary &&
                  data.summary.summary.map((item: any, index: number) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.userId}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.agentName}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.totalCalls}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.totalTalkTime}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.incomingTotal}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.incomingMissed}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.incomingAvgPerHour.toFixed(2)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.incomingTalkTime}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.outgoingTotal}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{item.outgoingAvgPerHour.toFixed(2)}</div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryDetail;
