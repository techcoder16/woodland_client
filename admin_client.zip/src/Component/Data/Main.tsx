import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState, AppDispatch } from "../../redux/store";

import ToasterGen from "../../helper/Toaster";
import { callsData } from "../../redux/dataStore/callsSlice";
import moment from "moment";

// Define types
interface TimerData {
  [key: string]: string;
}

const Main = () => {
  const dataCalls = useSelector((state: RootState) => state.calls);
  const [elapsedTimes, setElapsedTimes] = useState<TimerData>({});
  const dispatch = useDispatch<AppDispatch>();

  const getElapsedTime = (startTime: string, previousElapsedTime: string = "00:00:00") => {
    const start = moment(startTime);
    const now = moment();
    const duration = moment.duration(now.diff(start));

    const previousDuration = moment.duration(previousElapsedTime);

    const totalDuration = duration.add(previousDuration);

    return `${String(totalDuration.hours()).padStart(2, '0')}:${String(totalDuration.minutes()).padStart(2, '0')}:${String(totalDuration.seconds()).padStart(2, '0')}`;
  };

  useEffect(() => {
    // Dispatch an action to fetch data from API (assuming async action creator)
    
    console.log(dataCalls.timers)
    const interval = setInterval(() => {
      dispatch(callsData());
      // Update elapsed times every second
      setElapsedTimes((prevTimes) => {
        const updatedTimes: TimerData = { ...prevTimes };
        Object.keys(updatedTimes).forEach((userId) => {
          updatedTimes[userId] = getElapsedTime(prevTimes[userId], updatedTimes[userId]);
        });
        return updatedTimes;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [dispatch]);

  const getStatusColor = useCallback((status: string, userId: string,timer:string) => {
    if (status === "open" || (status === 'open'  && timer)) {
      try {
        const idleDuration = timer
        const [hours, minutes, seconds] = idleDuration.split(":").map(Number);

        const idleInSeconds = hours * 3600 + minutes * 60 + seconds;
        const maxIdleTimeInSeconds = 30 * 60; // 30 minutes in seconds

        if (idleInSeconds > maxIdleTimeInSeconds) {
          return "bg-red-500";
        }
      } catch (e) {
        return "bg-blue-500";
      }
    }

    switch (status) {
      case "idle":
        return "bg-blue-400";
      case "inactive":
        return "bg-gray-300";
      case "active":
        return "bg-green-500";
      case "open":
        return "bg-blue-500";
      case "inuse":
        return "bg-red-500";
      default:
        return "bg-gray-300";
    }
  }, [elapsedTimes]);

  return (
    <>
      <ToasterGen />
      <div>
        <div className="grid w-full grid-cols-1 md:grid-cols-7 lg:grid-cols-7 gap-4 mt-20">
          {dataCalls &&
            dataCalls.calls &&
            dataCalls.calls.map((item: any, index: number) => (
              <div key={index} className="flex flex-col bg-white border-2 border-solid shadow-lg p-4">
                <div className="ml-2 md:ml-4">
                  <p className="text-line font-dmsansf text-lg font-semibold ">
                    {item.first_name + " " + item.last_name}
                  </p>
                </div>
                <div className="lg:flex g items-center justify-center md:justify-start mb-2">
                  <div className={`m-auto uppercase ${getStatusColor(item.presence, item.uid,item.timer)}`}>
                    <p className="p-8 text-white left-0 font-semibold break-all text-xs">
                      {item.presence === "open" ? 'IDLE' : item.presence === "inactive" ? "Offline" : item.presence}
                    </p>
                  </div>
                </div>
                {item.presence === "open" && (
                  <div className="ml-2 md:ml-4">
                    <p className="text-line font-dmsans text-md font-normal text-gray-400">
                      Idle Time: {item.timer}
                    </p>
                  </div>
                )}
              </div>
            ))}
        </div>
      </div>
    </>
  );
};

export default Main;
