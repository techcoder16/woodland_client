import React from 'react';
import { FieldValues, UseFormRegister } from 'react-hook-form';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';

interface SelectFieldProps {
  label: string;
  name: string;
  options: { label: string; value: string }[]; // Define options as an array of label-value pairs
  register: UseFormRegister<FieldValues>;
  error?: string;
  defaultValue?: string;
  onChange?: (value: string) => void; // Add onChange callback as a prop
}

const SelectField: React.FC<SelectFieldProps> = ({
  label,
  name,
  options,
  register,
  error,
  defaultValue = '',
  onChange,
}) => {
  // React-hook-form `register` doesn't directly support custom components like `@radix-ui/react-select`
  // To integrate, use `setValue` and `onChange` manually
  const handleChange = (value: string) => {
    if (onChange) {
      onChange(value); // Call the passed onChange function with the selected value
    }
  };

  return (
    <div className=" p-3 rounded-sm">
      <div className="flex items-center w-full">
        <label className="text-gray-700 font-medium mr-4 w-32">{label}</label>

        <Select
          defaultValue={defaultValue}
          onValueChange={(value) => handleChange(value)} // Attach `onValueChange` handler
        >
          <SelectTrigger className="p-2 border border-gray-300 rounded flex w-full">
            <SelectValue placeholder="Select an option" />
          </SelectTrigger>
          <SelectContent>
            {options.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {error && <p className="text-red-500 mt-1 mx-2 justify-center flex">{error}</p>}
    </div>
  );
};

export default SelectField;
