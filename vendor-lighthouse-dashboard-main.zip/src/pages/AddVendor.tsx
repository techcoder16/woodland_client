import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Check, ArrowLeft, ArrowRight } from "lucide-react";
import StandardInfo from './Vendor/StandardInfo';
import InternalInfo from './Vendor/InternalInfo';
import BankDetails from './Vendor/BankDetails';
import WebLogin from './Vendor/WebLogin';
import Attachments from './Vendor/Attachments';
import { MainNav } from "@/components/MainNav";

const AddVendor = () => {
  const [currentStep, setCurrentStep] = useState(0);

  
const  titles = ['Mr', 'Mrs', 'Mr & Mrs','Ms','Dr','Sir','Other'];
// const salutaions = ['First Name', 'Last Name', 'Full Name', 'Title + First Name', 'Title + Last Name', 'Title + First Name'

// ]

const formSchema = z.object({
  landlord: z.boolean().optional(),
  vendor: z.boolean().optional(),
  type: z.enum(['Individual', 'Company'], {
    errorMap: () => ({ message: 'Invalid Type value. Please select one of the following options: "Company, Individual".' }),
  }),
  title: z.enum(['mr', 'mrs', 'miss', 'ms', 'dr', 'prof'], {
    errorMap: () => ({ message: 'Invalid title value. Please select one of the following options: "mr", "mrs", "miss", "ms", "dr", "prof".' }),
  }),
  firstName: z.string().nonempty('First Name is required'),
  lastName: z.string().nonempty('Last Name is required'),
  company: z.string().optional(),
  salutation: z.string().optional(),
  postCode: z.string().nonempty('Post Code is required'),
  addressLine: z.string().nonempty('Address Line is required'),
  addressLine2: z.string(),
  town: z.string(),
  country: z.string(),
  phoneHome: z.string(),
  phoneMobile: z.string(),
  fax: z.string(),
  email: z.string(),
  webste: z.string(),

  pager: z.string(),
  birthplace: z.string(),
  nationality: z.string(),
  passportNumber: z.string(),
  acceptLHA: z.string(),
  label: z.string(),
  status: z.string(),
  branch:z.string(),
  source:z.string(),
  dnrvfn:z.boolean()  , 
  ldhor:z.boolean()   ,
  sales_fee:z.string(),
  management_fee:z.string(),
  finders_fee:z.string(),
  sales_fee_a:z.string(),
  management_fee_a:z.string(),
  finders_fee_a:z.string(),
  nrl_ref:z.string(),
  nrl_rate:z.string(),

  vat_number:z.string(),
  landlord_full_name:z.string(),
  landlord_contact:z.string(),
  bank_body:z.string(),
  username:z.string(),
  password:z.string(),
  
bank_address_line_1:z.string(),
bank_address_line_2:z.string(),
bank_town:z.string(),
bank_post_code:z.string(),
bank_country:z.string(),

});


  
const { register, handleSubmit, formState: { errors } } = useForm({
  resolver: zodResolver(formSchema),
});

const onSubmit = (data: any) => {
  console.log('Form Data:', data);
};


const steps = [
  { label: "Standard Info", component: <StandardInfo  register = {register} errors = {errors}/> },
  { label: "Internal Info", component: <InternalInfo register = {register} errors = {errors} /> },
  { label: "Bank Details", component: <BankDetails  register = {register} errors = {errors}  /> },
  { label: "Web Login", component: <WebLogin   register = {register} errors = {errors} /> },
  { label: "Attachments", component: <Attachments    register = {register} errors = {errors}/> },
];






  

  const isLastStep = currentStep === steps.length - 1;

 

  return (
    <div className="min-h-screen bg-background text-foreground">
        <MainNav />
      <div className="container mx-auto max-w-3xl">
        <h1 className="text-4xl font-bold  mb-8">Add New Vendor</h1>

        {/* Stepper Navigation */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            {steps.map((step, index) => (
              <div key={index} className="flex-1 text-center">
                <div
                  className={`w-10 h-10 rounded-full mx-auto mb-2 flex items-center justify-center 
                  ${index <= currentStep ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"}`}
                >
                  {index < currentStep ? <Check className="h-5 w-5" /> : index + 1}
                </div>
                <p className={`text-sm ${index <= currentStep ? "text-blue-600" : "text-gray-600"}`}>
                  {step.label}
                </p>
              </div>
            ))}
          </div>
          <Progress value={((currentStep + 1) / steps.length) * 100} className="h-2" />
        </div>

        {/* Form Content */}
        <Card className="p-6  shadow-md">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {steps[currentStep].component}

            <div className="flex justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCurrentStep((prev) => Math.max(prev - 1, 0))}
                disabled={currentStep === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" /> Previous
              </Button>
              {isLastStep ? (
                <Button type="submit">
                  Submit <Check className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={() => setCurrentStep((prev) => Math.min(prev + 1, steps.length - 1))}
                >
                  Next <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default AddVendor;
