import React from 'react';
import { MainNav } from "@/components/MainNav";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { vendorSchema, type VendorData } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";

const steps = [
  { title: "Basic Info", fields: ["name"] },
  { title: "Contact", fields: ["email", "phone"] },
  { title: "Address", fields: ["address"] },
  { title: "Company", fields: ["company"] },
  { title: "Review", fields: [] },
];

const AddVendor = () => {
  const [currentStep, setCurrentStep] = React.useState(0);
  const { toast } = useToast();
  
  const form = useForm<VendorData>({
    resolver: zodResolver(vendorSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      address: "",
      company: "",
    },
  });

  const onSubmit = (data: VendorData) => {
    console.log(data);
    toast({
      title: "Vendor added successfully",
      description: "The vendor has been added to the system.",
    });
  };

  const currentFields = steps[currentStep].fields;
  const isLastStep = currentStep === steps.length - 1;

  return (
    <div className="min-h-screen flex flex-col bg-background font-montserrat">
      <MainNav />
      <div className="container mx-auto p-4 md:p-6 max-w-2xl">
        <h1 className="text-3xl font-bold tracking-tight mb-8 text-foreground">Add New Vendor</h1>

        <div className="flex justify-between mb-8 overflow-x-auto">
          {steps.map((step, index) => (
            <div
              key={step.title}
              className={`flex flex-col items-center px-2 ${
                index <= currentStep ? "text-primary" : "text-muted-foreground"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full border-2 flex items-center justify-center mb-2 ${
                  index <= currentStep ? "border-primary" : "border-muted"
                }`}
              >
                {index < currentStep ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <span>{index + 1}</span>
                )}
              </div>
              <span className="text-sm whitespace-nowrap">{step.title}</span>
            </div>
          ))}
        </div>

        <Card className="p-6 bg-card text-card-foreground">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {currentFields.map((fieldName) => (
                <FormField
                  key={fieldName}
                  control={form.control}
                  name={fieldName as keyof VendorData}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="capitalize text-foreground">{fieldName}</FormLabel>
                      <FormControl>
                        <Input {...field} className="bg-background text-foreground" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}

              {isLastStep && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-foreground">Review Information</h3>
                  {Object.entries(form.getValues()).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-border">
                      <span className="font-medium capitalize text-foreground">{key}</span>
                      <span className="text-muted-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
                  disabled={currentStep === 0}
                  className="font-lucida"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                </Button>
                
                {isLastStep ? (
                  <Button type="submit" className="font-lucida">
                    Submit <Check className="ml-2 h-4 w-4" />
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={() => setCurrentStep((prev) => Math.min(steps.length - 1, prev + 1))}
                    className="font-lucida"
                  >
                    Next <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                )}
              </div>
            </form>
          </Form>
        </Card>
      </div>
    </div>
  );
};

export default AddVendor;